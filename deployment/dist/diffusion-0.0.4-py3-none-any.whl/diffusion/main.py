import cv2
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import torch
import argparse
import os
import time
import random

from controlnet_aux import OpenposeDetector
from diffusers import ControlNetModel

# from utils import canny_edge_detection, openpose_detection
from diffusion.utils import image_utils
from diffusion.generate import StableDiffusionWithSAGAndControlNet

def generate(prompt, seed, batch_size, controlNet_image, controlNet_type, style_flag, sag_scale, controlnet_cond_scale, style_file_path):
    # prompt settings
    num_inference_steps = 20            # Number of denoising steps, using less for controlnet
    guidance_scale = 7.5                # Scale for classifier-free guidance
    generator = torch.manual_seed(seed)   # Seed generator to create the inital latent noise
    batch_size = 1
    

    # load controlnet models
    if controlNet_type == "canny":
        control_img = image_utils.canny_edge_detection(controlNet_image)
        controlnet = ControlNetModel.from_pretrained("lllyasviel/sd-controlnet-canny", torch_dtype=torch.float16)
    elif controlNet_type == "openpose":
        openpose = OpenposeDetector.from_pretrained("lllyasviel/ControlNet")
        control_img = image_utils.openpose_detection(controlNet_image, openpose)
        controlnet = ControlNetModel.from_pretrained("fusing/stable-diffusion-v1-5-controlnet-openpose", torch_dtype=torch.float16)
    else:
        control_img = None
        controlnet = None
    
    if style_flag == "T":
        prompt += " in <pop-art> style"



    # setup torch device. Need gpu for cpu_offload in sequence.
    torch_device = "cuda" if torch.cuda.is_available() else "cpu"

    # instantiate and generate image
    stablediffusion_model = StableDiffusionWithSAGAndControlNet(torch_device, controlnet, style_file_path)

    output_image = stablediffusion_model.generateDiffusion(prompt, 
                                                           control_img, 
                                                           generator, 
                                                           batch_size, 
                                                           num_inference_steps=num_inference_steps,
                                                           controlnet_conditioning_scale=controlnet_cond_scale,
                                                           guidance_scale=guidance_scale,
                                                           sag_scale=sag_scale    
                                                           )
    

    if not os.path.exists("results"):
        os.mkdir("results")
    result_filename = time.strftime("%Y%m%d-%H%M%S") + ".png"

    output_image.save(os.path.join("results", result_filename))
    print(f"Diffused image saved at {os.path.join('results', result_filename)}")

def take_input():
    print("Inside take_input ", os.getcwd())
    prompt                  = input("Prompt (str)\t: ")
    seed                    = input("Seed (int)\t: ")
    batch_size              = input("Batch Size (int)\t: ")
    controlNet_image        = input("Control Image filepath (str)\t: ")
    controlNet_type         = input("ControlNet type (str:Canny/Openpose/empty)\t: ")
    style_flag              = input("Style Flag (str: T/F)\t: ")
    sag_scale               = input("SAG scale (float)\t: ")
    controlnet_cond_scale   = input("ControlNet Condition scale (float)\t: ")
    style_file_path         = input("Style model filepath (str)\t: ")

    print("Received input")
    print(prompt, seed, batch_size, controlNet_image, controlNet_type, style_flag, sag_scale, controlnet_cond_scale)
    seed = int(seed) 

    batch_size = 1

    controlNet_image = os.path.join("control_images", controlNet_image)

    if controlNet_type.lower() not in ["canny", "openpose"]:
        controlNet_type = None
    
    if style_flag == "T":
        prompt += " in <pop-art> style"
    
    sag_scale = float(sag_scale)
    controlnet_cond_scale = float(controlnet_cond_scale)


    return [prompt, seed, batch_size, controlNet_image, controlNet_type, style_flag, sag_scale, controlnet_cond_scale, style_file_path]

    
def main():
    print("Current working directory", os.getcwd())
    user_inp = take_input()
    if user_inp[0] is None:
        return
    else:
        prompt, seed, batch_size, controlNet_image, controlNet_type, style_flag, sag_scale, controlnet_cond_scale, style_file_path = user_inp

    generate(prompt, seed, batch_size, controlNet_image, controlNet_type, style_flag, sag_scale, controlnet_cond_scale, style_file_path)



if __name__ == '__main__':
    main()
    

